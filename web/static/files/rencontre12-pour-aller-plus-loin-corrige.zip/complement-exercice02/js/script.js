// Rencontre 12 : exercices facultatifs autonomes.
// Ce fichier n'inclut aucune solution aux exercices essentiels.
// Rafraîchissez la page entre les tests si vous modifiez les tableaux.

let gFruits = ["🍓", "🍋", "🍏", "🍇", "🍊"];
let gPrix = [4.99, 1.95, 2.49, 6.45, 1.45];
let gJoueurs = ["crewmate", "crewmate", "impostor", "impostor", "crewmate", "impostor"];

// Écouteurs fournis : ne pas modifier.
function init(){
    document.querySelector(".bouton3").addEventListener("click", faireAchats);
    document.querySelector(".bouton5").addEventListener("click", amogus);
}

// TODO 1 : partir de 20 $, retirer chaque prix avec une boucle, afficher le solde (2.67).
function faireAchats(){
    let argent = 20;
    let i = 0;
    while(i < gPrix.length){
        argent -= gPrix[i];
        i += 1;
    }
    alert("Il vous reste " + argent.toFixed(2) + " dollars");
}

// TODO 2 : parcourir gJoueurs, compter les crewmates et impostors puis comparer.
function amogus(){
    let nbImpostors = 0;
    let nbCrewmates = 0;
    let i = 0;
    while(i < gJoueurs.length){
        if(gJoueurs[i] == "impostor"){
            nbImpostors += 1;
        }else if(gJoueurs[i] == "crewmate"){
            nbCrewmates += 1;
        }
        i += 1;
    }
    if(nbImpostors >= nbCrewmates){
        alert("aaaaaaaaa ! C’est peine perdue ! 💀");
    }else{
        alert("Il y a encore de l’espoir 🙏");
    }
}
