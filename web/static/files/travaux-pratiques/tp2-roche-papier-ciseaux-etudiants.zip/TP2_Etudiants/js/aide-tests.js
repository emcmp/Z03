// OUTILS DE VERIFICATION FOURNIS - NE PAS MODIFIER CE FICHIER.
// Ces outils permettent de tester l'étape R7 independamment des conditions R9.
// Les valeurs de test sont temporaires et ne comptent pas comme une partie.

let sauvegardeCompteursTest = null;

function testerCompteurs() {
  if (sauvegardeCompteursTest != null) {
    return;
  }

  sauvegardeCompteursTest = {
    nbConfrontations: nbConfrontations,
    confrontationsNulles: confrontationsNulles,
    victoiresJoueur1: victoiresJoueur1,
    victoiresJoueur2: victoiresJoueur2,
    partiesGagneesJoueur1: partiesGagneesJoueur1,
    partiesGagneesJoueur2: partiesGagneesJoueur2
  };

  // 5 confrontations = 1 victoire J1 + 2 victoires J2 + 2 nulles.
  nbConfrontations = 5;
  confrontationsNulles = 2;
  victoiresJoueur1 = 1;
  victoiresJoueur2 = 2;
  partiesGagneesJoueur1 = 3;
  partiesGagneesJoueur2 = 4;
  afficherResultat();

  document.querySelector('#idBtnJouer').disabled = true;
  document.querySelector('#idBtnTesterCompteurs').disabled = true;
  document.querySelector('#idBtnFinTestCompteurs').disabled = false;
  document.querySelector('#idStatutTests').textContent =
    'Mode test actif : comparez les six nombres affiches aux valeurs ci-dessus.';
}

function terminerTestCompteurs() {
  if (sauvegardeCompteursTest == null) {
    return;
  }
  nbConfrontations = sauvegardeCompteursTest.nbConfrontations;
  confrontationsNulles = sauvegardeCompteursTest.confrontationsNulles;
  victoiresJoueur1 = sauvegardeCompteursTest.victoiresJoueur1;
  victoiresJoueur2 = sauvegardeCompteursTest.victoiresJoueur2;
  partiesGagneesJoueur1 = sauvegardeCompteursTest.partiesGagneesJoueur1;
  partiesGagneesJoueur2 = sauvegardeCompteursTest.partiesGagneesJoueur2;
  sauvegardeCompteursTest = null;
  afficherResultat();

  document.querySelector('#idBtnJouer').disabled = false;
  document.querySelector('#idBtnTesterCompteurs').disabled = false;
  document.querySelector('#idBtnFinTestCompteurs').disabled = true;
  document.querySelector('#idStatutTests').textContent =
    'Test terminé : les valeurs du jeu ont ete restaurées.';
}

function testerImagesNeutres() {
  // Pour R8 seulement : au prochain clic sur JOUER, preparerImages()
  // devrait effacer ces couleurs provisoires (avant les conditions R9).
  document.querySelector('#idPhotoJ1').className = 'rouge';
  document.querySelector('#idPhotoJ2').className = 'vert';
  document.querySelector('#idStatutTests').textContent =
    'Couleurs provisoires appliquées. Cliquez sur JOUER : les deux images devraient devenir grises (avant R9).';
}

document.querySelector('#idBtnTesterCompteurs').addEventListener('click', testerCompteurs);
document.querySelector('#idBtnFinTestCompteurs').addEventListener('click', terminerTestCompteurs);
document.querySelector('#idBtnTesterImages').addEventListener('click', testerImagesNeutres);

// R9 — Outil facultatif : choisir les 2 tirages du prochain duel.
// Ce fichier est FOURNI : l'étudiant n'a pas à comprendre son mécanisme.
// Aucun code de victoire ni condition de jeu n'est programmé ici.
function testerDuelChoisi() {
  if (sauvegardeCompteursTest != null) {
    document.querySelector('#idStatutTests').textContent =
      'Termine d’abord le test R7 avec « Revenir au jeu ».';
    return;
  }
  const choix1 = Number(document.querySelector('#idChoixTestJ1').value);
  const choix2 = Number(document.querySelector('#idChoixTestJ2').value);
  const hasardOriginal = Math.random;
  let tirage = 0;
  try {
    Math.random = function () {
      tirage += 1;
      if (tirage == 1) {
        return (choix1 + 0.1) / 3;
      }
      return (choix2 + 0.1) / 3;
    };
    jouer();
  } finally {
    Math.random = hasardOriginal;
  }
  document.querySelector('#idStatutTests').textContent =
    'Duel déclenché : compare les images, les couleurs et les compteurs.';
}

document.querySelector('#idBtnTesterDuel').addEventListener('click', testerDuelChoisi);
