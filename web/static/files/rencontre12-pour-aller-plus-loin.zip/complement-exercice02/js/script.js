// Rencontre 12 : exercices facultatifs autonomes.
// Ce fichier n'inclut aucune solution aux exercices essentiels.
// Rafraîchissez la page entre les tests si vous modifiez les tableaux.

let gFruits = ["🍓", "🍋", "🍏", "🍇", "🍊"];
let gPrix = [4.99, 1.95, 2.49, 6.45, 1.45];
let gJoueurs = ["crewmate", "crewmate", "impostor", "impostor", "crewmate", "impostor"];

// Écouteurs fournis : ne pas modifier.
function init(){
    document.querySelector(".bouton3").addEventListener("click", faireAchats);
    document.querySelector(".bouton5").addEventListener("click", amogus);
}

// TODO 1 : partir de 20 $, retirer chaque prix avec une boucle, afficher le solde (2.67).
function faireAchats(){
    // TODO : compléter.
}

// TODO 2 : parcourir gJoueurs, compter les crewmates et impostors puis comparer.
function amogus(){
    // TODO : compléter.
}
