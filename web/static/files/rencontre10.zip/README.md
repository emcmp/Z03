# Rencontre 10 — Fonctions avec paramètres et valeurs de retour

Cette archive contient les deux exercices de la rencontre 10.

## Pour commencer

1. Décompressez l'archive.
2. Ouvrez le dossier `exercice01`, puis le fichier `index.html` dans votre navigateur.
3. Complétez les tâches TODO du fichier `js/script.js` avec Visual Studio Code.
4. Testez votre code à l'aide des boutons de la page Web.
5. Poursuivez avec le dossier `exercice02`.

Les écouteurs d'événements sont déjà préparés; vous n'avez pas à les modifier.

- **Exercice 1 :** réutiliser des fonctions avec paramètres et valeurs de retour.
- **Exercice 2 :** créer des fonctions paramétrées pour modifier des éléments de la page Web.

Les exercices 3 et 4 du laboratoire historique ne font pas partie de cette rencontre.
